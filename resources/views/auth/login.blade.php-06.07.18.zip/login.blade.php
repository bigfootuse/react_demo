<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <meta name="description" content="ERC 20"> -->
    <!-- <meta name="keywords" content="ERC 20"> -->
    <!-- <meta name="author" content="ERC 20"> -->
    <title>Login</title>

    <!-- Bootstrap css -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/auth/bootstrap.css')}} ">

    <!-- diamoreum registerpage css -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/auth/style.css')}} ">
    <!-- diamoreum registerpage css -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/auth/responsive.css')}} ">
    <link rel="shortcut icon" href="{{asset('assets/images/favicon.png')}}">

</head>

<body>
    <!-- Sign in start -->
    <div class="container-fluid login-box">
        <div class="row">
            <div class="col-md-12 col-lg-6 form-bg login-form-bg">
                <img src="{{asset('assets/auth/images/login.svg')}}" alt="signin" class="img-fluid">
            </div>
            <div class="login-form col-md-12 col-lg-6 d-flex-center">
                <div class="col-sm-12">
                    <div class="text-center">
                        <h2 class="title">Sign In</h2>
                        <span class="titleline"><em></em></span>
                        <!-- @if($errors->any())<div class="alert alert-danger"><ul>@foreach($errors->all() as $error)<li>{{$error}}</li>@endforeach</ul></div>@endif -->
                        @if(session()->has('error')) <div class="alert alert-danger"> {{ session()->get('error') }} </div>  @endif
                        @if(session()->has('success')) <div class="alert alert-success"> {{ session()->get('success') }} </div> @endif

                    </div>

                    <form action="{{ url('login-post') }}" method="post" id="register-form" class="tab-content active">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}" >
                        <div class="form-group">

                            <input type="email" name="email" class="form-control" placeholder="Email" required="">
                            <span></span>

                            @if($errors->has('email'))
                                <div class="text-danger pt-2 pl-3">
                                    {{ $errors->first('email') }}
                                </div>
                            @endif
                            <span></span>

                        </div>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control" placeholder="Password" >
                            @if($errors->has('password'))
                                <div class="text-danger pt-2 pl-3">
                                    {{ $errors->first('password') }}
                                </div>
                            @endif
                            <span></span>

                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-login text-center">login</button>
                        </div>
                        <div class="row mt-5">
                            <div class="col-sm-7 text-left">
                                Do not have The {{$f_coin   }} account?  <a href="{{ url('register') }}" class="p-0 m-0">Sign Up</a>
                            </div>
                            <div class="col-sm-5 text-right">
                                <a href="{{url('forgot-password')}}">Forgot your password?</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- latest jquery-->
    <script src="{{asset('assets/js/jquery-3.2.1.min.js')}}" type="text/javascript"></script>
    <!-- popper js-->
    <script src="{{asset('assets/js/popper.min.js')}}" type="text/javascript"></script>
    <!-- Bootstrap js-->
    <script src="{{asset('assets/js/bootstrap.js')}}" type="text/javascript"></script>

    </body>
    </html>

